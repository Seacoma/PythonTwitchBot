# CCCRewrite
A decent EDU Mail Bot

Features:
Multi college selection,
2cap or manual mode,
Multi-Apply mode,
Human Emulation using Selenium,
Multi-email support,
Multiple supported browsers
